using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interaction : MonoBehaviour
{
    //public new gameobject;

   // public void OnCollisionEnter(Collision coll)
    //{
       // if (coll.gameobject.tag == "Cheese")
        //{
           // Destroy(this.gameobject);
        //}
    //}

    // Update is called once per frame
    void Update()
    {
        //if (triggerActive && Input.GetKeyDown(KeyCode.Space))
        //{
          //  SomeCoolAction();
        //}
    }

    //public void SomeCoolAction()
    //{
        //Make triangles interact and maybe create another thing between them//

        
    //}
}

